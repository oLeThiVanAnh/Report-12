//
//  FriendInfo.swift
//  DHChat
//
//  Created by haipv on 11/21/16.
//  Copyright © 2016 haipv. All rights reserved.
//

import Foundation
class FriendInfo {
    var client_id:String = ""
    var key:String = ""
    var name:String = ""
    var message:String = ""
}
